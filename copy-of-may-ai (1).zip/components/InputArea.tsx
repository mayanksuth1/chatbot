import React, { useState, useRef, useEffect } from 'react';
import { Send, Paperclip, X, Image as ImageIcon, Mic } from 'lucide-react';
import { Attachment } from '../types';
import { fileToBase64 } from '../services/geminiService';

interface InputAreaProps {
  onSend: (text: string, attachments: Attachment[]) => void;
  disabled: boolean;
}

const InputArea: React.FC<InputAreaProps> = ({ onSend, disabled }) => {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [text]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if ((!text.trim() && attachments.length === 0) || disabled) return;
    onSend(text, attachments);
    setText('');
    setAttachments([]);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newAttachments: Attachment[] = [];
      for (let i = 0; i < e.target.files.length; i++) {
        const file = e.target.files[i];
        try {
          const base64 = await fileToBase64(file);
          newAttachments.push({
            mimeType: file.type,
            url: URL.createObjectURL(file),
            data: base64
          });
        } catch (err) {
          console.error("Failed to process file", err);
        }
      }
      setAttachments(prev => [...prev, ...newAttachments]);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 pb-6">
      {attachments.length > 0 && (
        <div className="flex gap-3 mb-3 overflow-x-auto py-2">
          {attachments.map((att, idx) => (
            <div key={idx} className="relative group flex-shrink-0">
              <div className="w-20 h-20 rounded-xl border border-[#374151] overflow-hidden bg-[#111827] relative">
                {att.mimeType.startsWith('image') ? (
                  <img src={att.url} alt="attachment" className="w-full h-full object-cover" />
                ) : (
                  <div className="flex items-center justify-center w-full h-full text-[#94A3B8]">
                    <Paperclip size={24} />
                  </div>
                )}
              </div>
              <button
                onClick={() => removeAttachment(idx)}
                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
              >
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className={`relative bg-[#1F2937] border border-[#374151] shadow-lg rounded-3xl overflow-hidden transition-all duration-200 ${disabled ? 'opacity-50 cursor-not-allowed' : 'focus-within:ring-1 focus-within:ring-[#0EA5E9] focus-within:border-[#0EA5E9]'}`}>
        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask Astra..."
          disabled={disabled}
          className="w-full bg-transparent text-[#E2E8F0] placeholder-[#64748B] px-5 py-4 pr-12 focus:outline-none resize-none max-h-[200px] min-h-[56px]"
          rows={1}
        />

        <div className="flex items-center justify-between px-3 pb-3 pt-1">
          <div className="flex items-center gap-2">
             <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              className="hidden"
              multiple
              accept="image/*,application/pdf"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={disabled}
              className="p-2 text-[#94A3B8] hover:text-[#0EA5E9] hover:bg-[#0EA5E9]/10 rounded-full transition-colors"
              title="Add image or file"
            >
              <ImageIcon size={20} />
            </button>
            <button
              disabled={disabled}
              className="p-2 text-[#94A3B8] hover:text-[#0EA5E9] hover:bg-[#0EA5E9]/10 rounded-full transition-colors"
              title="Voice input (coming soon)"
            >
              <Mic size={20} />
            </button>
          </div>

          <button
            onClick={handleSend}
            disabled={(!text.trim() && attachments.length === 0) || disabled}
            className={`p-2 rounded-full transition-all duration-200 ${
              (text.trim() || attachments.length > 0) && !disabled
                ? 'bg-[#0EA5E9] text-white shadow-lg shadow-[#0EA5E9]/20 hover:bg-[#0284C7] hover:scale-105 active:scale-95'
                : 'bg-[#374151] text-[#64748B] cursor-not-allowed'
            }`}
          >
            <Send size={20} />
          </button>
        </div>
      </div>
      <div className="text-center mt-3">
         <p className="text-xs text-[#64748B]">
           Astra can make mistakes. Check important info.
         </p>
      </div>
    </div>
  );
};

export default InputArea;
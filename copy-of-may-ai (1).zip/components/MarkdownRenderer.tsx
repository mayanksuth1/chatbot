import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import remarkGfm from 'remark-gfm';

interface MarkdownRendererProps {
  content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      className="prose prose-invert max-w-none prose-p:leading-relaxed prose-pre:p-0 prose-pre:bg-transparent prose-pre:shadow-none"
      components={{
        code({ node, inline, className, children, ...props }: any) {
          const match = /language-(\w+)/.exec(className || '');
          return !inline && match ? (
            <div className="rounded-lg overflow-hidden my-4 border border-[#374151] shadow-sm bg-[#0B1120]">
              <div className="bg-[#1F2937] px-4 py-2 text-xs font-mono text-[#94A3B8] border-b border-[#374151] flex justify-between items-center">
                <span>{match[1]}</span>
                <span className="text-[10px] uppercase tracking-wider">Code</span>
              </div>
              <SyntaxHighlighter
                style={vscDarkPlus}
                language={match[1]}
                PreTag="div"
                customStyle={{ margin: 0, borderRadius: 0, background: '#0B1120' }}
                {...props}
              >
                {String(children).replace(/\n$/, '')}
              </SyntaxHighlighter>
            </div>
          ) : (
            <code className="bg-[#374151] text-[#14B8A6] px-1.5 py-0.5 rounded text-sm font-mono border border-[#4B5563]" {...props}>
              {children}
            </code>
          );
        },
        table({ children }) {
           return (
             <div className="overflow-x-auto my-4 rounded-lg border border-[#374151] shadow-sm">
               <table className="min-w-full divide-y divide-[#374151] text-sm">
                 {children}
               </table>
             </div>
           )
        },
        thead({ children }) {
           return <thead className="bg-[#1F2937]">{children}</thead>
        },
        th({ children }) {
           return <th className="px-4 py-3 text-left text-xs font-medium text-[#94A3B8] uppercase tracking-wider">{children}</th>
        },
        td({ children }) {
           return <td className="px-4 py-3 whitespace-nowrap text-[#E2E8F0] border-t border-[#374151]">{children}</td>
        },
        a({ children, href }) {
          return (
            <a href={href} target="_blank" rel="noopener noreferrer" className="text-[#0EA5E9] hover:text-[#0284C7] underline decoration-[#0EA5E9]/50">
              {children}
            </a>
          )
        },
        p({ children }) {
            return <p className="text-[#E2E8F0] mb-4 last:mb-0 leading-relaxed">{children}</p>
        },
        li({ children }) {
            return <li className="text-[#E2E8F0]">{children}</li>
        },
        strong({ children }) {
            return <strong className="font-bold text-white">{children}</strong>
        }
      }}
    >
      {content}
    </ReactMarkdown>
  );
};

export default MarkdownRenderer;
import React from 'react';
import { Plus, MessageSquare, Settings, HelpCircle } from 'lucide-react';
import { ChatSession } from '../types';

interface SidebarProps {
  sessions: Record<string, ChatSession>;
  currentSessionId: string | null;
  isOpen: boolean;
  onToggle: () => void;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  currentSessionId,
  isOpen,
  onToggle,
  onSelectSession,
  onNewChat
}) => {
  const sessionList = (Object.values(sessions) as ChatSession[]).sort((a, b) => b.updatedAt - a.updatedAt);

  return (
    <>
      {/* Mobile Overlay */}
      <div 
        className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-40 md:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onToggle}
      />

      {/* Sidebar Content */}
      <aside 
        className={`fixed inset-y-0 left-0 z-50 w-[280px] bg-[#111827] border-r border-[#1F2937] transform transition-transform duration-300 ease-in-out flex flex-col ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 shadow-xl md:shadow-none`}
      >
        <div className="p-4">
          <button 
            onClick={() => { onNewChat(); if (window.innerWidth < 768) onToggle(); }}
            className="flex items-center gap-3 w-full px-4 py-3 bg-[#0EA5E9] hover:bg-[#0284C7] text-white rounded-xl transition-all shadow-md hover:shadow-lg group"
          >
            <Plus size={20} className="text-white" />
            <span className="font-medium text-sm">New chat</span>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
            <div className="px-3 py-2 text-xs font-medium text-[#94A3B8] uppercase tracking-wider">Recent</div>
            {sessionList.map(session => (
              <button
                key={session.id}
                onClick={() => { onSelectSession(session.id); if (window.innerWidth < 768) onToggle(); }}
                className={`flex items-center gap-3 w-full px-3 py-2.5 text-left rounded-lg text-sm transition-colors group ${currentSessionId === session.id ? 'bg-[#1F2937] text-[#E2E8F0] font-medium border border-[#374151]' : 'text-[#94A3B8] hover:bg-[#1F2937]/50 hover:text-[#E2E8F0]'}`}
              >
                <MessageSquare size={16} className={currentSessionId === session.id ? 'text-[#0EA5E9]' : 'text-[#64748B] group-hover:text-[#94A3B8]'} />
                <span className="truncate">{session.title}</span>
              </button>
            ))}
            {sessionList.length === 0 && (
                <div className="px-3 text-[#64748B] text-sm italic">No recent history</div>
            )}
        </div>

        <div className="p-4 border-t border-[#1F2937] space-y-1">
           <button className="flex items-center gap-3 w-full px-3 py-2 text-[#94A3B8] hover:text-[#E2E8F0] hover:bg-[#1F2937] rounded-lg text-sm transition-colors">
             <HelpCircle size={18} />
             <span>Help & FAQ</span>
           </button>
           <button className="flex items-center gap-3 w-full px-3 py-2 text-[#94A3B8] hover:text-[#E2E8F0] hover:bg-[#1F2937] rounded-lg text-sm transition-colors">
             <Settings size={18} />
             <span>Settings</span>
           </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
import { GoogleGenAI } from "@google/genai";
import { ModelId, Message, Role, Attachment } from '../types';

const API_KEY = process.env.API_KEY || '';

// Initialize the client
const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateResponseStream = async (
  modelId: ModelId,
  history: Message[],
  newMessage: string,
  attachments: Attachment[],
  onChunk: (text: string) => void,
  onComplete: () => void,
  onError: (error: Error) => void
) => {
  try {
    // Prepare the history for the chat context
    // Note: We filter out empty text messages or failed states if necessary
    const historyForSdk = history.map(msg => ({
      role: msg.role,
      parts: [
        { text: msg.text },
        ...(msg.attachments?.map(att => ({
          inlineData: {
            mimeType: att.mimeType,
            data: att.data
          }
        })) || [])
      ]
    }));

    // Create the chat session
    const chat = ai.chats.create({
      model: modelId,
      history: historyForSdk,
    });

    // Prepare current message content
    const currentMessageParts: any[] = [{ text: newMessage }];
    
    if (attachments && attachments.length > 0) {
      attachments.forEach(att => {
        currentMessageParts.push({
          inlineData: {
            mimeType: att.mimeType,
            data: att.data
          }
        });
      });
    }

    // Send message with streaming
    // Using sendMessageStream which accepts { message: ... }
    // Since we are sending multiple parts (text + image), we construct the message content carefully.
    // The SDK simplifies this: for multi-part, we usually pass the parts array to contents, 
    // but in chat.sendMessageStream, the `message` argument can be a string or a Part array.
    
    const result = await chat.sendMessageStream({ 
      message: currentMessageParts.length === 1 && currentMessageParts[0].text 
        ? currentMessageParts[0].text 
        : currentMessageParts 
    });

    for await (const chunk of result) {
        // The chunk is a GenerateContentResponse
        if (chunk.text) {
            onChunk(chunk.text);
        }
    }
    
    onComplete();

  } catch (error) {
    console.error("Gemini API Error:", error);
    onError(error instanceof Error ? error : new Error('Unknown error occurred'));
  }
};

export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove the Data URL prefix (e.g., "data:image/png;base64,")
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};